jquery-migrate
===============

shim repo for jQuery Migrate package 

Install via [bower](http://twitter.github.com/bower/):

    $ bower install jquery-migrate
    
bower package info:

    $ bower info jquery-migrate
