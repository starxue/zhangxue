
// http://html.adobe.com/webplatform/layout/shapes

Modernizr.addTest('shapes', Modernizr.testAllProps('shapeOutside', 'content-box', true));
