// https://developer.mozilla.org/en-US/docs/API/Pointer_Lock_API

Modernizr.addTest('pointerlock',!!Modernizr.prefixed('pointerLockElement', document));

